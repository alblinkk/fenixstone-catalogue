const sections=[...document.querySelectorAll('.slide')];
const dots=[...document.querySelectorAll('.dots a')];
const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      const i=sections.indexOf(e.target);
      dots.forEach((d,n)=>d.classList.toggle('active',n===i));
    }
  });
},{threshold:.55});
sections.forEach(s=>observer.observe(s));

let lock=false;
window.addEventListener('wheel',e=>{
  if(lock || Math.abs(e.deltaY)<20) return;
  const current=sections.findIndex(s=>{
    const r=s.getBoundingClientRect();
    return r.top>=-window.innerHeight*.45 && r.top<=window.innerHeight*.45;
  });
  const next=e.deltaY>0?current+1:current-1;
  if(next>=0 && next<sections.length){
    lock=true;
    sections[next].scrollIntoView({behavior:'smooth'});
    setTimeout(()=>lock=false,650);
  }
},{passive:true});

dots.forEach((d,i)=>d.addEventListener('click',e=>{
  e.preventDefault();
  sections[i].scrollIntoView({behavior:'smooth'});
}));
